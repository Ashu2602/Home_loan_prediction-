# Home-Loan-Prediction

Standard Bank Home loan prediction was made by myself and my group as a project for university.
This is an end to end project starting from how we are storing data on AWS and then how we are trying to predict credit worthiness of a person or in simple terms 
whether a person will recieve a loan or not.
I will go ahead and try attaching the presentation as well.

## Code Readabilty

We have tried to make the code as readable as possible and we integreated a front end using streamlit. 
To know more about how you can use streamlit on your devices, go to https://streamlit.io/ and explore how easy it is to give a face to your ML projects.

# Forage

The above project is a part of STANDARD BANK FORAGE virtual internship experience.
Please vist www.theforage.com and check out other internships which can benefit you in your respective domains.
